<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
// needed to seperate the ISO number from the language file constant _ISO
$iso = split( '=', _ISO );
// xml prolog
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<?php mosShowHead(); ?>
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<link href="<?php echo $mosConfig_live_site;?>/templates/siteground33/css/template_css.css" rel="stylesheet" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body >

<table cellpadding="0" cellspacing="0" border="0" class="height">

	<tr>
		<td class="bg_left" rowspan="2" class="height"></td>
		<td valign="top" align="center">
<!-- -->

<table width="800" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td1"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td2"></td>
					<td class="td3"></td>
					<td class="td4"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td5"></td>
					<td class="td6"></td>
					<td class="td7" valign="top" align="left">
						<div id="topnavigation">
							<table cellpadding="0" cellspacing="0">
								<tr>
							<?php
								$database->setQuery("SELECT id, name, link FROM #__menu WHERE menutype='mainmenu' and parent='0' AND access<='$gid' AND sublevel='0' AND published='1' ORDER BY ordering LIMIT 6");
								$rows = $database->loadObjectList();
								foreach($rows as $row) {
									echo "<td width='14'><img src='$mosConfig_live_site/templates/siteground33/images/separator.jpg'></td><td><a class='topnavigation' href='$row->link&Itemid=$row->id' >$row->name</a></td>";
								}
							?>
								</tr>
							</table>
						</div>
					</td>
					<td class="td8"></td>
					<td class="td9"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td rowspan="2" class="left" valign="top"><div class="td10"></div></td>
					<td class="td11"></td>
					<td rowspan="2" class="right" valign="top"><div class="td12"></div></td>
				</tr>
				<tr>
					<td class="td13" valign="top" align="left">
						<div style="padding:10px;"> 
							<?php mosMainBody(); ?>
							<? $sg = 'banner'; include "templates.php"; ?>
						</div>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td14"></td>
					<td class="td15"></td>
					<td class="td16"></td>
				</tr>
				<tr>
					<td class="td17"></td>
					<td class="td18"></td>
					<td class="td19"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<!-- -->
		</td>	
		<td class="bg_right"valign="top"></td>
	</tr>		
</table>
<p align="center" class="copyright"><? $sg = ''; include "templates.php"; ?></p>
<!-- -->		
</body>
</html>