<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?><?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
// needed to seperate the ISO number from the language file constant _ISO
$iso = split( '=', _ISO );
// xml prolog
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php mosShowHead(); ?>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="<?php echo $mosConfig_live_site;?>/templates/siteground27/css/template_css.css" rel="stylesheet" type="text/css"/>
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body>
<center>
<table width="840" height="577" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table width="840" height="38" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td rowspan="3" class="td1"></td>
					<td colspan="5" class="td2"></td>
					<td rowspan="2" class="td3"></td>
					<td class="td4"></td>
					<td class="td5"></td>
					<td rowspan="3" class="td6"></td>
				</tr>
				<tr>
					<td>
						<a href="#"><img src="templates/siteground27/images/siteground_07.jpg" width="46" height="14" alt="" border="0"></a></td>
					<td class="td8"></td>
					<td>
						<a href="#"><img src="templates/siteground27/images/siteground_09.jpg" width="67" height="14" alt="" border="0"></a></td>
					<td class="td10"></td>
					<td>
						<a href="#"><img src="templates/siteground27/images/siteground_11.jpg" width="80" height="14" alt="" border="0"></a></td>
					<td>
						<a href="#"><img src="templates/siteground27/images/siteground_12.jpg" width="57" height="14" alt="" border="0"></a></td>
					<td class="td13"></td>
				</tr>
				<tr>
					<td colspan="8" class="td14"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="840" height="119" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td15"></td>
					<td class="td16"></td>
					<td class="td17"></td>
				</tr>
				<tr>
					<td class="td18"></td>
					<td class="td19"></td>
					<td class="td20"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td valign="top" class="height">
			<table width="840" border="0" cellpadding="0" cellspacing="0" class="height">
				<tr>
					<td class="td21"></td>
					<td class="td22" valign="top" align="left">
						<?php mosLoadModules ( 'left' ); ?>
						<? $sg = 'banner'; include "templates.php"; ?>					
					</td>
					<td class="td23" valign="top" align="left">
						<div style="padding:10px;"><?php mosMainBody(); ?></div>
					</td>
					<td class="td24"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="840" height="20" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td25"></td>
					<td class="td26"></td>
					<td class="td27" align="center">
						<span class="copyright"><? $sg = ''; include "templates.php"; ?></span>
					</td>
					<td class="td28"></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</center>
</body>
</html>
