<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
// needed to seperate the ISO number from the language file constant _ISO
$iso = explode( '=', _ISO );
// xml prolog
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<?php mosShowHead(); ?>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<link href="<?php echo $mosConfig_live_site;?>/templates/siteground16/css/template_css.css" rel="stylesheet" type="text/css"/>
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center>
<table id="Table_01" width="900" height="670" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table id="Table_04" width="900" height="133" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td rowspan="2">
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_01.jpg" width="50" height="48" alt=""></td>
					<td colspan="9">
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_02.jpg" width="850" height="38" alt=""></td>
				</tr>
				<tr>
					<td colspan="9">
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_03.jpg" width="850" height="10" alt=""></td>
				</tr>
				<tr>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_04.jpg" width="50" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_05.jpg" width="10" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_06.jpg" width="157" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_07.jpg" width="11" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_08.jpg" width="193" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_09.jpg" width="11" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_10.jpg" width="199" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_11.jpg" width="11" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_12.jpg" width="198" height="70" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_13.jpg" width="60" height="70" alt=""></td>
				</tr>
				<tr>
					<td colspan="10">
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_14.jpg" width="900" height="15" alt=""></td>
				</tr>
			</table></td>
	</tr>
	<tr>
		<td>
			<table id="Table_03" width="900" height="512" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td background="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_15.jpg" width="50" height="495">
						</td>
					<td background="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_16.jpg" width="10" height="495">
						</td>
					<td background="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_17.jpg" width="168" height="495" valign="top" style="padding:5px;">
					
					<?php mosLoadModules ( 'left' ); ?>
					<? $sg = 'banner'; include "templates.php"; ?>

					<td background="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_18.jpg" width="622" height="495" valign="top" style="padding:5px;">
						<?php mosMainBody(); ?></td>
					<td background="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_19.jpg" width="50" height="495">
						</td>
				</tr>
				<tr>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_20.jpg" width="50" height="17" alt=""></td>
					<td colspan="3">
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_21.jpg" width="800" height="17" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_22.jpg" width="50" height="17" alt=""></td>
				</tr>
			</table></td>
	</tr>
	<tr>
		<td>
			<table id="Table_02" width="900" height="25" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_23.jpg" width="50" height="25" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_24.jpg" width="800" height="25" alt=""></td>
					<td>
						<img src="<?php echo $mosConfig_live_site;?>/templates/siteground16/images/real_estate_25.jpg" width="50" height="25" alt=""></td>
				</tr>
			</table></td>
	</tr>
</table>
	<table align="center">
		<tr><td>
		<p><? $sg = ''; include "templates.php"; ?></p>
		</td></tr>
	</table>
</center>
</body>
</html>
