<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
// needed to seperate the ISO number from the language file constant _ISO
$iso = split( '=', _ISO );
// xml prolog
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<?php mosShowHead(); ?>
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<link href="<?php echo $mosConfig_live_site;?>/templates/siteground25/css/template_css.css" rel="stylesheet" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body bgcolor="#FFFFFF">
<center>
<table width="800" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2">
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td1"></td>
					<td class="td2"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td valign="top" class="height">
			<table width="214" border="0" cellpadding="0" cellspacing="0" class="height">
				<tr>
					<td class="td3"></td>
					<td rowspan="2" class="td4">
					
					<object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" id="obj1" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" border="0" width="200" height="160">
					<param name="movie" value="<?php echo $mosConfig_live_site;?>/templates/siteground25/images/sg.swf">
					<param name="quality" value="High">
					<embed src="<?php echo $mosConfig_live_site;?>/templates/siteground25/images/sg.swf" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="obj1" width="200" height="160"></object>
					</td>
					<td class="td5"></td>
				</tr>
				<tr>
					<td class="td6"></td>
					<td class="td7"></td>
				</tr>
				<tr>
					<td class="td8" valign="top"></td>
					<td class="td9" valign="top" align="left">
						<?php mosLoadModules ( 'left' ); ?>
						<? $sg = 'banner'; include "templates.php"; ?>
					</td>
					<td class="td10bg" valign="top"><div class="td10"></div></td>
				</tr>
			</table>
		</td>
		<td valign="top">
			<table width="586" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td11"></td>
				</tr>
				<tr>
					<td class="td12" align="left">
						<?php mosMainBody(); ?>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2" valign="top">
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td13"></td>
					<td class="td14"></td>
					<td class="td15"></td>
					<td class="td16"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<table width="800" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td17"></td>
					<td class="td18"></td>
					<td class="td19"></td>
					<td class="td20" align="center">
						<span class="copyright"><? $sg = ''; include "templates.php"; ?></span>
					</td>
					<td class="td21"></td>
				</tr>
				<tr>
					<td class="td22"></td>
					<td class="td23"></td>
					<td class="td24"></td>
					<td class="td25"></td>
					<td class="td26"></td>
				</tr>
			</table></td>
	</tr>
</table>
</center>
</body>
</html>