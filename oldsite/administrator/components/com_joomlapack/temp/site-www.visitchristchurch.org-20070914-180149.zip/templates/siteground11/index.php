<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?><?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
// needed to seperate the ISO number from the language file constant _ISO
$iso = split( '=', _ISO );
// xml prolog
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php mosShowHead(); ?>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="<?php echo $mosConfig_live_site;?>/templates/siteground11/css/template_css.css" rel="stylesheet" type="text/css"/>
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center>
<table id="Table_01" width="719" height="513" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td rowspan="7" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_01.jpg" width="8" height="428">
		</td>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_02.jpg" width="241" height="9">
		</td>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_03.jpg" width="459" height="9">
		</td>
		<td rowspan="7" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_04.jpg" width="10" height="428">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="9">
		</td>
	</tr>
	<tr>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_05.jpg" width="241" height="19">
		</td>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_06.jpg" width="459" height="19">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="19" alt=""></td>
	</tr>
	<tr>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_07.jpg" width="241" height="12">
		</td>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_08.jpg" width="459" height="12">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="12" alt=""></td>
	</tr>
	<tr>
		<td colspan="6" valign="bottom" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_09.jpg" width="700" height="186">
		<?php mosPathWay(); ?>
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="186" alt=""></td>
	</tr>
	<tr>
		<td colspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_10.jpg" width="700" height="5">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="5" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_11.jpg" width="160" height="10">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_12.jpg" width="10" height="10">
		</td>
		<td colspan="3" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_13.jpg" width="530" height="10">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" rowspan="2" bgcolor="#E4E4E4" width="160" height="207" valign="top" align="left">
		<?php mosLoadModules ( 'left' ); ?>
		<? $sg = 'banner'; include "templates.php"; ?>		
		</td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_15.jpg" width="10" height="207">
		</td>
		<td colspan="3" rowspan="2" bgcolor="#E4E4E4" width="530" height="207" valign="top" align="left">
		<?php mosMainBody(); ?>
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="187" alt=""></td>
	</tr>
	<tr>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_17.jpg" width="8" height="20">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_18.jpg" width="10" height="20">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="20" alt=""></td>
	</tr>
	<tr>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_19.jpg" width="8" height="14">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_20.jpg" width="14" height="14">
		</td>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_21.jpg" width="672" height="14">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_22.jpg" width="14" height="14">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_23.jpg" width="10" height="14">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="14" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_24.jpg" width="8" height="10">
		</td>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_25.jpg" width="241" height="9">
		</td>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_26.jpg" width="459" height="9">
		</td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_27.jpg" width="10" height="10">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="9" alt=""></td>
	</tr>
	<tr>
		<td colspan="4" rowspan="2" align="center" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_28.jpg" width="241" height="19">
	    <font style="color:#ffffff;"><?php echo mosCurrentDate(); ?></font>
		</td>
		<td colspan="2" rowspan="2" align="center" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_29.jpg" width="459" height="19">
		<p style="color:#fefefe;"><? $sg = ''; include "templates.php"; ?></p>
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="1" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_30.jpg" width="8" height="20" >
		</td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_31.jpg" width="10" height="20">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="18" alt=""></td>
	</tr>
	<tr>
		<td colspan="4" rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_32.jpg" width="241" height="12">
		</td>
		<td colspan="2" rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_33.jpg" width="459" height="12" alt="">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="2" alt=""></td>
	</tr>
	<tr>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_34.jpg" width="8" height="10">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_35.jpg" width="10" height="10">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="10">
		</td>
	</tr>
	<tr>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_36.jpg" width="8" height="10">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_37.jpg" width="14" height="10">
		</td>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_38.jpg" width="672" height="10">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_39.jpg" width="14" height="10">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/sg_12_40.jpg" width="10" height="10">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="1" height="10" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="8" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="146" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="10" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="71" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="445" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="14" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground11/images/spacer.gif" width="10" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
</center>
</body>
</html>