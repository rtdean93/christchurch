<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?><?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
// needed to seperate the ISO number from the language file constant _ISO
$iso = split( '=', _ISO );
// xml prolog
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php mosShowHead(); ?>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="<?php echo $mosConfig_live_site;?>/templates/siteground12/css/template_css.css" rel="stylesheet" type="text/css"/>
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center>
<table id="Table_01" width="703" height="523" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td rowspan="6" background ="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_01.jpg" width="40" height="70">
		</td>
		<td colspan="2" rowspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_02.jpg" width="6" height="70">
		</td>
		<td colspan="14" rowspan="5" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/bg.jpg" width="371" height="50">
		</td>
		<td rowspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_04.jpg" width="11">
		</td>
		<td colspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_05.jpg" width="230" height="17">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_06.jpg" width="44" height="17">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="17" alt=""></td>
	</tr>
	<tr>
		<td colspan="6" rowspan="5" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_07.jpg" width="230" height="53">
		</td>
		<td rowspan="5" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_08.jpg" width="44" height="53">
        </td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="4" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="4" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="19" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="6" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" rowspan="2">
			<a href="index.php?option=com_frontpage&Itemid=1"><img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_20.jpg" width="91" height="55" border="0"></a></td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_21.jpg" width="1" height="55">
		</td>
		<td colspan="3" rowspan="2">
			<a href="#"><img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_22.jpg" width="91" height="55" border=""></a></td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_23.jpg" width="1" height="55">
		</td>
		<td colspan="3" rowspan="2">
			<a href="#"><img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_24.jpg" width="91" height="55" border=""></a></td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_25.jpg" width="1" height="55">
		</td>
		<td colspan="2" rowspan="2">
			<a href="index.php?option=com_contact&Itemid=3"><img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_26.jpg" width="91" height="55" border=""></a></td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_27.jpg" width="4" height="55">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="20" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_28.jpg" width="40" height="54">
		</td>
		<td colspan="2" rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_29.jpg" width="6" height="54">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_30.jpg" width="11" height="35">
		</td>
		<td colspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_31.jpg" width="230" height="35">
		</td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_32.jpg" width="44" height="54">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="35" alt=""></td>
	</tr>
	<tr>
		<td colspan="14" rowspan="7" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_33.jpg" width="371" height="102">
		</td>
		<td rowspan="7" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_34.jpg" width="11" height="102">
		</td>
		<td colspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_35.jpg" width="230" height="19">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="19" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" rowspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_36.jpg" width="42" height="83">
		</td>
		<td rowspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_37.jpg" width="4" height="83">
		</td>
		<td colspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_38.jpg" width="230" height="20">
		</td>
		<td rowspan="5" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_39.jpg" width="44" height="80">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="20" alt=""></td>
	</tr>
	<tr>
		<td colspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_40.jpg" width="230" height="20">
		<font class="date"><?php echo mosCurrentDate(); ?></font>
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="20" alt=""></td>
	</tr>
	<tr>
		<td colspan="6" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_41.jpg" width="230" height="19">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="19" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_42.jpg" width="77" height="19">
		</td>
		<form action='index.php' method='post'>
        <td width="109" height="19" id="search">
		<input class="inputboxs" type="text" name="searchword" size="10" value="<?php echo _SEARCH_BOX; ?>"  onblur="if(this.value=='') this.value='<?php echo _SEARCH_BOX; ?>';" onfocus="if(this.value=='<?php echo _SEARCH_BOX; ?>') this.value='';" />
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_44.jpg" width="11" height="19">
		</td>
		<td valign="top" width="28" height="19">
		<input type="image" src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_45.jpg" width="28" height="19" name="option" />
		</td>
		<input type="hidden" name="option" value="search" />
        </form>
		<td rowspan="3" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_46.jpg" width="5" height="24">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="19" alt=""></td>
	</tr>
	<tr>
		<td colspan="5" rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_47.jpg" width="225" height="5">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="2" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_48.jpg" width="44" height="10">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="3" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_49.jpg" width="42" height="7">
		</td>
		<td colspan="15" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_50.jpg" width="375" height="7">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_51.jpg" width="11" height="7">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_52.jpg" width="76" height="7">
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_53.jpg" width="1" height="7">
		</td>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_54.jpg" width="153" height="7">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="7" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_55.jpg" width="42" height="249">
		</td>
		<td colspan="17" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_56.jpg" width="462" height="249" valign="top" style="padding-left:4px;" align="left">
		<?php mosMainBody(); ?>
		</td>
		<td background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_57.jpg" width="1" height="249">
		</td>
		<td colspan="4" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_58.jpg" width="153" height="249" valign="top">
		<?php mosLoadModules ( 'left' ); ?>
		<? $sg = 'banner'; include "templates.php"; ?>	
		</td>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_59.jpg" width="44" height="250">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="249" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_60.jpg" width="42" height="6">
		</td>
		<td colspan="22" rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_61.jpg" width="616" height="6">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="1" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_62.jpg" width="44" height="47">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="5" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_63.jpg" width="42" height="42">
		</td>
		<td colspan="22" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_64.jpg" width="616" height="42" align="center">
		<p><? $sg = ''; include "templates.php"; ?></p>
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="42" alt=""></td>
	</tr>
	<tr>
		<td colspan="25" background="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/sg_13_65.jpg" width="702" height="11">
		</td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="11" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="40" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="2" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="4" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="90" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="18" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="7" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="66" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="42" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="6" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="43" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="2" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="89" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="4" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="76" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="1" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="109" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="28" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="5" height="1" alt=""></td>
		<td>
			<img src="<?php echo $mosConfig_live_site;?>/templates/siteground12/images/spacer.gif" width="44" height="1" alt=""></td>
		<td></td>
	</tr>
</table>


</center>
</body>
</html>