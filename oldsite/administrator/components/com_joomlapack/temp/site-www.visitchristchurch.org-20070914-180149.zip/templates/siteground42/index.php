<?php defined( "_VALID_MOS" ) or die( "Direct Access to this location is not allowed." );$iso = split( '=', _ISO );echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php mosShowHead(); ?>
<meta http-equiv="Content-Type" content="text/html" <?php echo _ISO; ?>" />
<?php if ( $my->id ) { initEditor(); } ?>
<?php echo "<link rel=\"stylesheet\" href=\"$GLOBALS[mosConfig_live_site]/templates/$GLOBALS[cur_template]/css/template_css.css\" type=\"text/css\"/>" ; ?>
<link rel="alternate" title="<?php echo $mosConfig_sitename; ?>" href="<?php echo $GLOBALS['mosConfig_live_site']; ?>/index2.php?option=com_rss&no_html=1" type="application/rss+xml" />
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body class="body">
<center>
<div class="all">
<div id="logo">
<div class="pway"><?php mosPathWay(); ?></div>
		<?php include'menu.php'; ?>
</div>
<div id="container">
<table cellpadding="0" cellspacing="0">
	<tr>
	<td class="leftcol" valign="top">
			<?php mosLoadModules('left'); ?>
	</td>
	<td class="maincol" valign="top">
		<div style="padding:0px 2px 0px 2px;">
			<?php mosMainBody(); ?>
		</div>
	</td>
	<td class="rightcol" valign="top">
			<?php mosLoadModules('right'); ?>
			<? $sg = 'banner'; include "templates.php"; ?>			
	</td>
	</tr>
</table>
<div class="footer_bg">
<div class="footer">
<? $sg = ''; include "templates.php"; ?>
</div>
</div>
</div>
</div>
</center>
</body>
</html>
