<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
?>
<?php echo "<?xml version=\"1.0\"?>"; ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<?php mosShowHead(); ?>
<link href="<?php echo $mosConfig_live_site;?>/templates/<?php echo $GLOBALS[cur_template];?>/css/template_css.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php echo $mosConfig_live_site;?>/images/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="<?php echo $mosConfig_sitename?>" href="<?php echo $mosConfig_live_site;?>/index.php?option=com_rss&feed=RSS2.0&no_html=1" />
</head>
<body>
<center>
<table cellpadding="0" cellspacing="0" border="0" class="height">

	<tr>
		<td class="bg_left" rowspan="2" class="height"></td>
		<td valign="top" align="center">
<!-- -->
<table width="800" height="600" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table width="800" height="101" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td1"></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="800" height="249" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td6" valign="top">
						<div style="padding:4px;">
							<?php mosLoadModules ( 'left' ); ?>
							<? $sg = 'banner'; include "templates.php"; ?>					
						</div>					
					</td>
					<td class="td7" valign="top">
						<div style="padding:10px;"> 
							<?php mosMainBody(); ?>
						</div>						
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table width="800" height="25" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="td8">
<p id="sgf" align="center">
 			<? $sg = ''; include "templates.php"; ?>
</p></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<!-- -->
		</td>	
		<td class="bg_right"valign="top"></td>
	</tr>		
</table>
<!-- -->
</center>
</body>
</html>